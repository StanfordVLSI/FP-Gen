./runTarget.pl lvt 1v0 1200 30 lvt 1v0 1100 30 lvt 1v0 1000 30 lvt 1v0  900 30 lvt 1v0  800 30 lvt 1v0 700 30 lvt 1v0 650 30 lvt 1v0 590 15

