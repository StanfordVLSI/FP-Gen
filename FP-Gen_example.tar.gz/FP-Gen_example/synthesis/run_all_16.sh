./runTarget.pl hvt 0v8 2000 8 hvt 0v8 1500 8 hvt 0v8 1300 8 hvt 0v8 1200 8 hvt 0v8 1100 8\
            svt 0v9 1000 8 svt 0v9 800 8 svt 0v9  700 8 svt 0v9  600 8 svt 0v9  500 8\
            lvt 1v0 600 8 lvt 1v0 500 8 lvt 1v0 450 8 lvt 1v0 400 8 lvt 1v0 350 8 lvt 1v0 300 8

