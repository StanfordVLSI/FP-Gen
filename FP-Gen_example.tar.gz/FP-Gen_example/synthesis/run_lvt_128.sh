./runTarget.pl lvt 1v0 1200 30  lvt 1v0 1100 30  lvt 1v0 1000 30  lvt 1v0  950 30  lvt 1v0  900 30 lvt 1v0 850 30 lvt 1v0 800 30 

