./runTarget.pl hvt 0v8 3500 30 hvt 0v8 3000 30 hvt 0v8 2500 30 hvt 0v8 2000 30 hvt 0v8 1500 30 hvt 0v8 1300 30\
            svt 0v9 1800 30 svt 0v9 1600 30 svt 0v9 1400 30 svt 0v9 1200 30 svt 0v9 1000 30 svt 0v9 900 30\
            lvt 1v0 1200 30 lvt 1v0 1100 30 lvt 1v0 1000 30 lvt 1v0  900 30 lvt 1v0  800 30 lvt 1v0 700 30 lvt 1v0 650 30

