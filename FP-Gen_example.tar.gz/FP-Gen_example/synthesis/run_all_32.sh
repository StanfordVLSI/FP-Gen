./runTarget.pl hvt 0v8 2500 15 hvt 0v8 2200 15 hvt 0v8 1900 15 hvt 0v8 1700 15 hvt 0v8 1600 15 \
            svt 0v9 1500 15 svt 0v9 1200 15 svt 0v9 900 15 svt 0v9 800 15 svt 0v9 750 15 \
            lvt 1v0 900 15 lvt 1v0 800 15 lvt 1v0 700 15 lvt 1v0 600 15 lvt 1v0 550 15 lvt 1v0 500 15 lvt 1v0 450 15

