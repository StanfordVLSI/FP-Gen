#!/usr/bin/perl


#get a sorted list of all report files
@files = <*/reports/*.mapped.timing.rpt>;
print "design, Vth, Vdd, mapped delay, routed delay, optimized delay, mapped core area, routed core area, optimized core area, mapped dynamic power, routed dynamic power, optimized dynamic power, mapped leakage power, routed leakage power, optimized leakage power\n";

foreach $file (@files) {
  $file =~ /(.vt_\dv\d_.*)\/reports\/(.*)\.(.vt)_(\dv\d)\.(.*)\.mapped\.timing\.rpt/;
  $folder_name=$1;
  $design_name = $2;
  $vt = $3;
  $vdd = $4;
  $target_delay = $5;
  $prefix = "$design_name.${vt}_$vdd.$target_delay";
  $optimized_prefix = "$design_name.optimized.${vt}_$vdd.$target_delay";

  @report_files = <$folder_name/reports/$prefix.mapped.timing.*>;
  $mapped_delay = 1000;
  foreach $report_file (@report_files) {
    open (REPORTFILE,"<$report_file") || die "Can't open $report_file $!";
    while(<REPORTFILE>) { 
      if ( $_ =~ /data arrival time\s+-?(\d+\.?\d*)/ && $1 < $mapped_delay) {    
	    $mapped_delay = $1;
      }
    }
    close REPORTFILE;
  }

  $mapped_core_area="";
  @report_files = <$folder_name/reports/$design_name.${vt}.$target_delay.mapped.area.*>;
  foreach $report_file (@report_files) {
    open (REPORTFILE,"<$report_file") || die "Can't open $report_file $!";
    while(<REPORTFILE>) {
      if ( $_ =~ /Total cell area:\s+(\d+\.?\d*)/ ) {
        $mapped_core_area = $1;
      }
    }
    close REPORTFILE;
  }

  $mapped_dynamic_power="";
  $mapped_leakage_power="";
  @report_files = <$folder_name/reports/$prefix.mapped.power.*>;
  foreach $report_file (@report_files) {
    open (REPORTFILE,"<$report_file") || die "Can't open $report_file $!";
    while(<REPORTFILE>) {
	 if ( $_ =~ /Total Dynamic Power\s*=\s+(\d+\.?\d*((e|E)-?\d+)?)\s*(.W)/ ) { 
		$mapped_dynamic_power = ($4 eq "uW")? $1 / 1000.0 : $1 ;
		$mapped_dynamic_power = ($4 eq " W")? $1 * 1000.0 : $mapped_dynamic_power ; 
	 }
	 if ( $_ =~ /Cell Leakage Power\s*=\s+(\d+\.?\d*((e|E)-?\d+)?)\s*(.W)/ ) {
           $mapped_leakage_power = ($4 eq "uW")? $1 / 1000.0: $1;
           $mapped_leakage_power = ($4 eq " W")? $1 * 1000.0: $mapped_leakage_power;
	 }
     }
    close REPORTFILE;
  }



  @report_files = <$folder_name/reports/$prefix.routed.timing.*>;
  $routed_delay = 1000;
  foreach $report_file (@report_files) {
    open (REPORTFILE,"<$report_file") || die "Can't open $report_file $!";
    while(<REPORTFILE>) { 
      if ( $_ =~ /data arrival time\s+-?(\d+\.?\d*)/ && $1 < $routed_delay) {    
	    $routed_delay = $1;
      }
    }
    close REPORTFILE;
  }

  $routed_core_area="";
  @report_files = <$folder_name/reports/$design_name.${vt}.$target_delay.routed.area.*>;
  foreach $report_file (@report_files) {
    open (REPORTFILE,"<$report_file") || die "Can't open $report_file $!";
    while(<REPORTFILE>) {
      if ( $_ =~ /Core Area:\s+(\d+\.?\d*)/ ) {
        $routed_core_area = $1;
      }
    }
    close REPORTFILE;
  }

  $routed_dynamic_power="";
  $routed_leakage_power="";
  @report_files = <$folder_name/reports/$prefix.routed.power.*>;
  foreach $report_file (@report_files) {
    open (REPORTFILE,"<$report_file") || die "Can't open $report_file $!";
    while(<REPORTFILE>) {
	 if ( $_ =~ /Total Dynamic Power\s*=\s+(\d+\.?\d*((e|E)-?\d+)?)\s*(.W)/ ) {    
		$routed_dynamic_power = ($4 eq "uW")? $1 /1000.0 : $1 ;
		$routed_dynamic_power = ($4 eq " W")? $1 * 1000.0 : $routed_dynamic_power ;
	 }
	 if ( $_ =~ /Cell Leakage Power\s*=\s+(\d+\.?\d*((e|E)-?\d+)?)\s*(.W)/ ) {
           $routed_leakage_power = ($4 eq "uW")? $1 / 1000.0: $1;
           $routed_leakage_power = ($4 eq " W")? $1 * 1000.0: $routed_leakage_power;
	 }
     }
    close REPORTFILE;
  }

  @report_files = <$folder_name/reports/$optimized_prefix.routed.timing.*>;
  $optimized_delay = 1000;
  foreach $report_file (@report_files) {
    open (REPORTFILE,"<$report_file") || die "Can't open $report_file $!";
    while(<REPORTFILE>) { 
      if ( $_ =~ /data arrival time\s+-?(\d+\.?\d*)/ && $1 < $optimized_delay) {    
	    $optimized_delay = $1;
      }
    }
    close REPORTFILE;
  }


  $optimized_core_area="";
  @report_files = <$folder_name/reports/$design_name.optimized.${vt}.$target_delay.routed.area.*>;
  foreach $report_file (@report_files) {
    open (REPORTFILE,"<$report_file") || die "Can't open $report_file $!";
    while(<REPORTFILE>) {
      if ( $_ =~ /Core Area:\s+(\d+\.?\d*)/ ) {
        $optimized_core_area = $1;
      }
    }
    close REPORTFILE;
  }

  $optimized_dynamic_power="";
  $optimized_leakage_power="";
  @report_files = <$folder_name/reports/$optimized_prefix.routed.power.*>;
  foreach $report_file (@report_files) {
    open (REPORTFILE,"<$report_file") || die "Can't open $report_file $!";
    while(<REPORTFILE>) {
	 if ( $_ =~ /Total Dynamic Power\s*=\s+(\d+\.?\d*((e|E)-?\d+)?)\s*(.W)/ ) {    
		$optimized_dynamic_power = ($4 eq "uW")? $1 / 1000.0: $1;
		$optimized_dynamic_power = ($4 eq " W")? $1 * 1000.0: $optimized_dynamic_power;
	 }
	 if ( $_ =~ /Cell Leakage Power\s*=\s+(\d+\.?\d*((e|E)-?\d+)?)\s*(.W)/ ) {
           $optimized_leakage_power = ($4 eq "uW")? $1 / 1000.0: $1;
           $optimized_leakage_power = ($4 eq " W")? $1 * 1000.0: $optimized_leakage_power;
	 }
     }
    close REPORTFILE;
  }

  $vdd =~ s/v/./;
  if ($mapped_delay != 1000)
  {
     print "${vt}_$target_delay, $vt, $vdd, $mapped_delay, $routed_delay, $optimized_delay, $mapped_core_area, $routed_core_area, $optimized_core_area, $mapped_dynamic_power, $routed_dynamic_power, $optimized_dynamic_power, $mapped_leakage_power, $routed_leakage_power, $optimized_leakage_power\n";
  }
}
