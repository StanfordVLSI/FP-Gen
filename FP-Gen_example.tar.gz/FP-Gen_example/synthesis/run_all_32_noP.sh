./runTarget.pl lvt 1v0 1100 15 lvt 1v0 1000 15 lvt 1v0 900 15 lvt 1v0 800 15 lvt 1v0 750 15 lvt 1v0 700 15 lvt 1v0 650 15

