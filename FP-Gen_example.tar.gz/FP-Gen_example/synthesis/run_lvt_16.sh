./runTarget.pl lvt 1v0 600 8 lvt 1v0 500 8 lvt 1v0 450 8 lvt 1v0 400 8 lvt 1v0 350 8 lvt 1v0 300 8

