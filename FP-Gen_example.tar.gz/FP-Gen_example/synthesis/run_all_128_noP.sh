./runTarget.pl lvt 1v0 1600 30  lvt 1v0 1500 30  lvt 1v0 1400 30  lvt 1v0  1300 30  lvt 1v0  1200 30 lvt 1v0 1050 30 lvt 1v0 1000 30 

