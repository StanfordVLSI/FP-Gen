./runTarget.pl lvt 1v0 900 15 lvt 1v0 800 15 lvt 1v0 700 15 lvt 1v0 600 15 lvt 1v0 550 15 lvt 1v0 500 15 lvt 1v0 450 15 lvt 1v0 400 15

