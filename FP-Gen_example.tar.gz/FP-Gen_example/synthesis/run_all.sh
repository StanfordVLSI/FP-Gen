./runTarget hvt 0v8 3500  hvt 0v8 3000  hvt 0v8 2500  hvt 0v8 2000  hvt 0v8 1500 hvt 0v8 1300
./runTarget svt 0v9 1800  svt 0v9 1600  svt 0v9 1400  svt 0v9 1200  svt 0v9 1000 svt 0v9 900
./runTarget lvt 1v0 1200  lvt 1v0 1100  lvt 1v0 1000  lvt 1v0  900  lvt 1v0  800  lvt 1v0 700 lvt 1v0 650

