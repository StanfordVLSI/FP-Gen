./runTarget.pl lvt 1v0 750 8 lvt 1v0 650 8 lvt 1v0 600 8 lvt 1v0 550 8 lvt 1v0 500 8 lvt 1v0 450 8 lvt 1v0 400 8

